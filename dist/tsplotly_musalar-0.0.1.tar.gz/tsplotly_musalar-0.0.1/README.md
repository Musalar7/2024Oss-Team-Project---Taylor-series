# Tay Series using plotly library

테일러급수를 plotly 라이브러리를 이용하여 표현하고 표기된 그래프에서 원본함수와 항의 차이점을 계산해주는 라이브러리입니다.

도움이 필요하시면 
https://github.com/Musalar7/2024Oss-Team-Project---Teylor-series/issues
여기로 issue 보내주세요.